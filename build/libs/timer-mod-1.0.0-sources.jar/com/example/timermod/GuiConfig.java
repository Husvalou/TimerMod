package com.example.timermod;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.io.IOException;

@SideOnly(Side.CLIENT)
public class GuiConfig extends GuiScreen {
    private final TimerModule timer;
    private GuiSlider speedSlider;
    private GuiButton closeButton;
    private GuiButton toggleKeyButton;
    private GuiButton guiKeyButton;
    private GuiSlider draggedSlider = null;

    public GuiConfig(TimerModule timer) {
        this.timer = timer;
    }

    @Override
    public void func_73866_w_() {
        int centerX = this.field_146294_l / 2;
        int centerY = this.field_146295_m / 2;

        speedSlider = new GuiSlider(1, centerX - 100, centerY - 30, 200, 20, "Speed: ", 
            timer.getMinSpeed(), timer.getMaxSpeed(), timer.getSpeed(), timer.getIncrement(),
            new GuiSlider.SliderCallback() {
                @Override
                public void onValueChanged(double value) {
                    timer.setSpeed(value);
                }
            });
        
        // Key bind buttons
        toggleKeyButton = new GuiButton(4, centerX - 100, centerY + 5, 200, 20, "Toggle Key: " + Config.getKeyName(Config.getToggleKey()));
        guiKeyButton = new GuiButton(5, centerX - 100, centerY + 30, 200, 20, "GUI Key: " + Config.getKeyName(Config.getGuiKey()));
        
        closeButton = new GuiButton(3, centerX - 50, centerY + 60, 100, 20, "Close");

        this.field_146292_n.add(speedSlider);
        this.field_146292_n.add(toggleKeyButton);
        this.field_146292_n.add(guiKeyButton);
        this.field_146292_n.add(closeButton);

        updateButtonText();
    }

    @Override
    protected void func_146284_a(GuiButton button) {
        if (button.field_146127_k == 3) {
            field_146297_k.func_147108_a(null);
        } else if (button.field_146127_k == 4) {
            // Start capturing toggle key
            timer.setWaitingForToggleKey(true);
            button.field_146126_j = "Press any key...";
        } else if (button.field_146127_k == 5) {
            // Start capturing GUI key
            timer.setWaitingForGuiKey(true);
            button.field_146126_j = "Press any key...";
        }
        updateButtonText();
    }

    private void updateButtonText() {
        if (!timer.isWaitingForToggleKey()) {
            toggleKeyButton.field_146126_j = "Toggle Key: " + Config.getKeyName(Config.getToggleKey());
        }
        if (!timer.isWaitingForGuiKey()) {
            guiKeyButton.field_146126_j = "GUI Key: " + Config.getKeyName(Config.getGuiKey());
        }
    }

    @Override
    public void func_73876_c() {
        super.func_73876_c();
        // Update keybind buttons when not waiting
        if (!timer.isWaitingForToggleKey() && !timer.isWaitingForGuiKey()) {
            updateButtonText();
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();

        // Title
        GlStateManager.func_179094_E();
        GlStateManager.func_179152_a(2.0F, 2.0F, 2.0F);
        this.func_73732_a(this.field_146289_q, "Timer Mod", this.field_146294_l / 4, 10, 0xFFFFFF);
        GlStateManager.func_179121_F();

        // Controls info
        String toggleKeyName = Config.getKeyName(Config.getToggleKey());
        String guiKeyName = Config.getKeyName(Config.getGuiKey());
        this.func_73732_a(this.field_146289_q, 
            toggleKeyName + ": Toggle | " + guiKeyName + ": GUI | ALT+Up/Down: Adjust", 
            this.field_146294_l / 2, this.field_146295_m / 2 + 90, 0xAAAAAA);
            
        // Credits - bottom right with gradient border
        int creditX = this.field_146294_l - 115;
        int creditY = this.field_146295_m - 50;
        int creditWidth = 110;
        int creditHeight = 40;
        int borderThickness = 2;
        
        // Draw transparent background (same as rest of UI)
        func_73734_a(creditX, creditY, creditX + creditWidth, creditY + creditHeight, 0xDD000000);
        
        // Draw gradient border (pink to white)
        int startColor = 0xFFFF69B4; // Hot pink
        int endColor = 0xFFFFFFFF; // White
        
        // Top border - gradient left to right
        for (int i = 0; i < creditWidth; i++) {
            float ratio = (float) i / (float) creditWidth;
            int color = interpolateColor(startColor, endColor, ratio);
            func_73734_a(creditX + i, creditY, creditX + i + 1, creditY + borderThickness, color);
        }
        
        // Bottom border - gradient left to right
        for (int i = 0; i < creditWidth; i++) {
            float ratio = (float) i / (float) creditWidth;
            int color = interpolateColor(startColor, endColor, ratio);
            func_73734_a(creditX + i, creditY + creditHeight - borderThickness, creditX + i + 1, creditY + creditHeight, color);
        }
        
        // Left border - gradient top to bottom
        for (int i = 0; i < creditHeight; i++) {
            float ratio = (float) i / (float) creditHeight;
            int color = interpolateColor(startColor, endColor, ratio);
            func_73734_a(creditX, creditY + i, creditX + borderThickness, creditY + i + 1, color);
        }
        
        // Right border - gradient top to bottom
        for (int i = 0; i < creditHeight; i++) {
            float ratio = (float) i / (float) creditHeight;
            int color = interpolateColor(startColor, endColor, ratio);
            func_73734_a(creditX + creditWidth - borderThickness, creditY + i, creditX + creditWidth, creditY + i + 1, color);
        }
        
        // Draw credits text
        this.func_73731_b(this.field_146289_q, "§dFree 4 Everyone", creditX + 8, creditY + 10, 0xFF1493);
        this.func_73731_b(this.field_146289_q, "§7Made by Hus", creditX + 8, creditY + 23, 0xAAAAAA);
        
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }
    
    private int interpolateColor(int startColor, int endColor, float ratio) {
        int r = (int) ((1 - ratio) * ((startColor >> 16) & 0xFF) + ratio * ((endColor >> 16) & 0xFF));
        int g = (int) ((1 - ratio) * ((startColor >> 8) & 0xFF) + ratio * ((endColor >> 8) & 0xFF));
        int b = (int) ((1 - ratio) * (startColor & 0xFF) + ratio * (endColor & 0xFF));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(null);
        }
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }

    @Override
    public void func_146274_d() {
        try {
            super.func_146274_d();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        int mouseX = Mouse.getEventX() * this.field_146294_l / this.field_146297_k.field_71443_c;
        int mouseY = this.field_146295_m - Mouse.getEventY() * this.field_146295_m / this.field_146297_k.field_71440_d - 1;
        
        // Handle slider dragging
        if (Mouse.getEventButtonState()) {
            for (Object button : this.field_146292_n) {
                if (button instanceof GuiSlider) {
                    GuiSlider slider = (GuiSlider) button;
                    if (slider.func_146116_c(this.field_146297_k, mouseX, mouseY)) {
                        this.draggedSlider = slider;
                        break;
                    }
                }
            }
        } else if (Mouse.getEventButton() != -1) {
            // Mouse released
            if (this.draggedSlider != null) {
                this.draggedSlider.func_146118_a(mouseX, mouseY);
                this.draggedSlider = null;
            }
        }
    }

    @Override
    protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (this.draggedSlider != null) {
            this.draggedSlider.func_146119_b(this.field_146297_k, mouseX, mouseY);
        }
    }

    @Override
    public void func_146281_b() {
        timer.setGuiConfig(null);
        // Cancel key capture if closing
        if (timer.isWaitingForToggleKey()) {
            timer.setWaitingForToggleKey(false);
        }
        if (timer.isWaitingForGuiKey()) {
            timer.setWaitingForGuiKey(false);
        }
    }
}
